import java.util.Scanner;

public class Library {
    private Book[] books = new Book[50];
    private int bookCount = 0;
    private Scanner sc = new Scanner(System.in);

    public void addBook() {
        if (bookCount >= books.length) {
            System.out.println("Library is full. Cannot add more books.");
            return;
        }

        System.out.print("Enter title: ");
        String title = sc.nextLine();
        System.out.print("Enter author: ");
        String author = sc.nextLine();
        System.out.print("Enter ISBN (13 digits): ");
        String isbn = sc.nextLine();
        if (isbn.length() != 13) {
            System.out.println("Invalid ISBN.");
            return;
        }
        System.out.print("Enter number of copies: ");
        int copies = sc.nextInt(); sc.nextLine();

        books[bookCount++] = new Book(title, author, isbn, copies);
        System.out.println("Book added successfully.");
    }

    public void removeBook() {
        System.out.print("Enter ISBN to remove: ");
        String isbn = sc.nextLine();

        for (int i = 0; i < bookCount; i++) {
            if (books[i].getISBN().equals(isbn)) {
                books[i] = books[--bookCount];
                books[bookCount] = null;
                System.out.println("Book removed.");
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void viewBooks() {
        if (bookCount == 0) {
            System.out.println("No books available.");
            return;
        }
        for (int i = 0; i < bookCount; i++) {
            books[i].displayInfo();
        }
    }

    public void borrowBook(Member m) {
        System.out.print("Enter ISBN to borrow: ");
        String isbn = sc.nextLine();
        for (int i = 0; i < bookCount; i++) {
            if (books[i].getISBN().equals(isbn)) {
                m.borrowBook(books[i]);
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void returnBook(Member m) {
        System.out.print("Enter ISBN to return: ");
        String isbn = sc.nextLine();
        for (int i = 0; i < bookCount; i++) {
            if (books[i].getISBN().equals(isbn)) {
                m.returnBook(books[i]);
                return;
            }
        }
        System.out.println("Book not found.");
    }
}