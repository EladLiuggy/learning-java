public class Book {
    private String title;
    private String author;
    private String ISBN;
    private int totalCopies;
    private int availableCopies;

    public Book(String title, String author, String ISBN, int totalCopies) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.totalCopies = totalCopies;
        this.availableCopies = totalCopies;
    }

    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getISBN() { return ISBN; }
    public int getTotalCopies() { return totalCopies; }
    public int getAvailableCopies() { return availableCopies; }

    public void borrowCopy() {
        if (availableCopies > 0) availableCopies--;
    }

    public void returnCopy() {
        if (availableCopies < totalCopies) availableCopies++;
    }

    public void displayInfo() {
        System.out.println("Title: " + title + ", Author: " + author + 
                           ", ISBN: " + ISBN + ", Available: " + availableCopies + "/" + totalCopies);
    }
}