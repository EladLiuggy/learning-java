import java.util.Scanner;

public class Member extends User implements Borrowable {
    private String[] borrowedISBNs = new String[3];
    private int count = 0;

    public Member(String name, String userId) {
        super(name, userId);
    }

    @Override
    public void borrowBook(Book book) {
        if (count >= 3) {
            System.out.println("Cannot borrow more than 3 books.");
        } else if (book.getAvailableCopies() > 0) {
            borrowedISBNs[count++] = book.getISBN();
            book.borrowCopy();
            System.out.println("Book borrowed successfully.");
        } else {
            System.out.println("No available copies.");
        }
    }

    @Override
    public void returnBook(Book book) {
        for (int i = 0; i < count; i++) {
            if (borrowedISBNs[i].equals(book.getISBN())) {
                book.returnCopy();
                borrowedISBNs[i] = borrowedISBNs[count - 1];
                borrowedISBNs[--count] = null;
                System.out.println("Book returned.");
                return;
            }
        }
        System.out.println("You did not borrow this book.");
    }

    @Override
    public void displayMenu(Library library) {
        Scanner sc = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\n--- Member Menu ---");
            System.out.println("1. View Books\n2. Borrow Book\n3. Return Book\n0. Logout");
            System.out.print("Enter choice: ");
            choice = sc.nextInt(); sc.nextLine();

            if (choice == 1) library.viewBooks();
            else if (choice == 2) library.borrowBook(this);
            else if (choice == 3) library.returnBook(this);
        } while (choice != 0);
    }
}