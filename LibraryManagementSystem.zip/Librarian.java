import java.util.Scanner;

public class Librarian extends User {
    public Librarian(String name, String userId) {
        super(name, userId);
    }

    @Override
    public void displayMenu(Library library) {
        Scanner sc = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\n--- Librarian Menu ---");
            System.out.println("1. Add Book\n2. Remove Book\n3. View All Books\n0. Logout");
            System.out.print("Enter choice: ");
            choice = sc.nextInt(); sc.nextLine();

            if (choice == 1) library.addBook();
            else if (choice == 2) library.removeBook();
            else if (choice == 3) library.viewBooks();
        } while (choice != 0);
    }
}