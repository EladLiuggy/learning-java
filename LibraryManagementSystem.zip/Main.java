import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner sc = new Scanner(System.in);
        int choice;

        System.out.println("=== Welcome to the Library System ===");

        do {
            System.out.println("\n1. Register as Librarian\n2. Register as Member\n0. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt(); sc.nextLine();

            if (choice == 1 || choice == 2) {
                System.out.print("Enter name: ");
                String name = sc.nextLine();
                System.out.print("Enter user ID: ");
                String id = sc.nextLine();
                User user = (choice == 1) ? new Librarian(name, id) : new Member(name, id);
                user.displayMenu(library);
            }
        } while (choice != 0);

        System.out.println("Thank you for using the system!");
    }
}